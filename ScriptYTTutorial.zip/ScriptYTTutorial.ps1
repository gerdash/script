﻿Install-Module xWebAdministration
Install-Module PsDesiredStateConfiguration

Configuration WebsiteDeployment
{
    param
    (
        # Target nodes to apply the configuration
        [string[]]$NodeName = 'localhost',
 
        # Name of the website to create
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [String]$WebSiteName1 = 'WebsiteOne',

        # Name of the website to create
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [String]$WebSiteName2 = 'WebsiteTwo'
    )

    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xWebAdministration -ModuleVersion 3.2.0

    Node $NodeName {
        WindowsFeature ISS {
            Ensure = 'Present'
            Name   = 'Web-Server'
        }
        WindowsFeature ISSConsole {
            Ensure    = 'Present'
            Name      = 'Web-Mgmt-Console'
            DependsOn = '[WindowsFeature]ISS'
        }
        WindowsFeature ISScriptingTools {
            Ensure    = 'Present'
            Name      = 'Web-Scripting-Tools'
            DependsOn = '[WindowsFeature]ISS'
        }
        WindowsFeature AspNet {
            Ensure    = 'Present'
            Name      = 'Web-Asp-Net45'
            DependsOn = @('[WindowsFeature]ISS')
        }

        xWebsite DefaultSite {
            Ensure = 'Present'
            Name   = 'Default Web Site'
            State  = 'Stopped'
        }
        File WebsiteFolder {
            Ensure          = 'Present'
            Type            = 'Directory'
            DestinationPath = "C:\inetpub\wwwroot\websites"
        }
        File $WebSiteName1 {
            Ensure          = 'Present'
            Type            = 'File'
            DestinationPath = "C:\inetpub\wwwroot\websites\websiteOne.html"
            Contents        = "<!DOCTYPE html>
            <title>Uno</title>
            </head>
            <body>
            <p>This is website one!</p>
            </body>
            </html>"
        }
        File $WebSiteName2 {
            Ensure          = 'Present'
            Type            = 'File'
            DestinationPath = "C:\inetpub\wwwroot\websites\websiteTwo.html"
            Contents        = "<!DOCTYPE html>
            <title>Uno</title>
            </head>
            <body>
            <p>This is website two!</p>
            </body>
            </html>"
        }
        xWebAppPool WebsitePool {
            Ensure = 'Present'
            State  = 'Started'
            Name   = 'task6'
        }
        xWebsite WebsiteOne {
            Ensure       = 'Present'
            State        = 'Started'
            Name         = $WebSiteName1
            PhysicalPath = "C:\inetpub\wwwroot\websites"
            BindingInfo  = MSFT_xWebBindingInformation {
                Protocol = 'http'
                Port     = 1234
            }
        }
        xWebsite WebsiteTwo {
            Ensure       = 'Present'
            State        = 'Started'
            Name         = $WebSiteName2
            PhysicalPath = "C:\inetpub\wwwroot\websites"
            BindingInfo  = MSFT_xWebBindingInformation {
                Protocol = 'http'
                Port     = 1235
            }
        }
        xWebApplication demoWebApplication {
            Name         = "task6"
            Website      = $WebSiteName1, $WebsiteName2
            WebAppPool   = "task6"
            PhysicalPath = "C:\inetpub\wwwroot\websites"
            Ensure       = 'Present'
            DependsOn    = @('[xWebsite]WebsiteOne', '[xWebsite]WebsiteTwo')
        }
    }
}
